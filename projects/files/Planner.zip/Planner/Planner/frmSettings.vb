﻿Public Class frmSettings

    Private Sub frmSettings_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        LoadSettings()

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        SaveSettings()
        Me.Close()

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Me.Close()

    End Sub

    Private Sub SaveSettings()

        If cmbMaxOn.SelectedIndex = 0 Then

            My.Settings.blnMaxOnClick = False

        Else

            My.Settings.blnMaxOnClick = True

        End If

        If cmbMinOn.SelectedIndex = 0 Then

            My.Settings.blnMinOnClick = False

        Else

            My.Settings.blnMinOnClick = True

        End If

    End Sub

    Private Sub LoadSettings()

        If My.Settings.blnMaxOnClick = True Then

            cmbMaxOn.SelectedIndex = 1

        Else

            cmbMaxOn.SelectedIndex = 0

        End If

        If My.Settings.blnMinOnClick = True Then

            cmbMinOn.SelectedIndex = 1

        Else

            cmbMinOn.SelectedIndex = 0

        End If

    End Sub

End Class