﻿Public Class frmMain

    Dim intScreenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
    Dim blnMaximized As Boolean = False

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        
        LoadAll()

        Minimize()

    End Sub

    Private Sub frmMain_MouseEnter(sender As Object, e As EventArgs) Handles MyBase.MouseEnter

        If My.Settings.blnMaxOnClick = False Then

            Maximize()

        End If

    End Sub

    Private Sub frmMain_MouseLeave(sender As Object, e As EventArgs) Handles MyBase.MouseLeave

        If My.Settings.blnMinOnClick = False Then

            ' This if is necessary because otherwise hovering over a control on the form will cause it to minimize
            If MousePosition.X < intScreenWidth - 600 Or MousePosition.X > intScreenWidth - 200 Or MousePosition.Y > 575 Then

                Minimize()
                SaveAll()

            End If

        End If

    End Sub

    Private Sub frmMain_MouseClick(sender As Object, e As MouseEventArgs) Handles MyBase.MouseClick, Label9.Click, Label8.Click, Label7.Click, Label6.Click, Label5.Click, Label4.Click, Label3.Click, Label2.Click, Label1.Click
        ' Handle click events on the form as well as all labels the same way so that the user may also click on a label to min/max the form

        If My.Settings.blnMinOnClick = True And blnMaximized = True Then

            Minimize()

        ElseIf My.Settings.blnMaxOnClick = True And blnMaximized = False Then

            Maximize()

        End If

    End Sub

    Private Sub Minimize()

        Me.Location = New Point(intScreenWidth - 300, 0)
        Me.Size = New Size(100, 25)

        blnMaximized = False

    End Sub

    Private Sub Maximize()

        Me.Size = New Size(400, 575)
        Me.Location = New Point(intScreenWidth - 600, 0)

        blnMaximized = True

    End Sub

    Private Sub btnSettings_Click(sender As Object, e As EventArgs) Handles btnSettings.Click

        frmSettings.ShowDialog()

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click

        Me.Close()

    End Sub

    Private Sub frmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        SaveAll()

    End Sub
    
    Private Sub SaveAll()

        My.Settings.strA1 = txtA1.Text
        My.Settings.strA2 = txtA2.Text
        My.Settings.strA3 = txtA3.Text
        My.Settings.strA4 = txtA4.Text
        My.Settings.strB5 = txtB5.Text
        My.Settings.strB6 = txtB6.Text
        My.Settings.strB7 = txtB7.Text
        My.Settings.strB8 = txtB8.Text

    End Sub

    Private Sub LoadAll()

        txtA1.Text = My.Settings.strA1
        txtA2.Text = My.Settings.strA2
        txtA3.Text = My.Settings.strA3
        txtA4.Text = My.Settings.strA4
        txtB5.Text = My.Settings.strB5
        txtB6.Text = My.Settings.strB6
        txtB7.Text = My.Settings.strB7
        txtB8.Text = My.Settings.strB8

    End Sub

End Class
