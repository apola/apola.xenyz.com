﻿Public Class Customer
    Inherits Person

    Private intCustomerNumber As Integer
    Private blnMailingList As Boolean
    Private strComments As String

    Property CustomerNumber() As Integer

        Get

            Return intCustomerNumber

        End Get

        Set(value As Integer)

            intCustomerNumber = value

        End Set

    End Property

    Property MailingList() As Boolean

        Get

            Return blnMailingList

        End Get

        Set(value As Boolean)

            blnMailingList = value

        End Set

    End Property

    Property Comments() As String

        Get

            Return strComments

        End Get

        Set(value As String)

            strComments = value

        End Set

    End Property

End Class
