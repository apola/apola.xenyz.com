﻿Public Class frmMain

    Public PreferredCustomers As Collection
    Public intCurrentCustomer As Integer

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        PreferredCustomers = New Collection

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        If frmSearch.ShowDialog() = Windows.Forms.DialogResult.OK Then

            LoadInfo()

        End If

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        If frmAdd.ShowDialog() = Windows.Forms.DialogResult.OK Then

            LoadInfo()

        End If

    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click

        If PreferredCustomers.Contains(intCurrentCustomer.ToString) Then

            If frmEdit.ShowDialog() = Windows.Forms.DialogResult.OK Then

                LoadInfo()

            End If

        Else

            MessageBox.Show("No customer selected.")

        End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click

        If PreferredCustomers.Contains(intCurrentCustomer.ToString) Then

            If MessageBox.Show("Are you sure you want to delete this customer?", "Delete Customer", MessageBoxButtons.YesNoCancel) = Windows.Forms.DialogResult.Yes Then

                PreferredCustomers.Remove(intCurrentCustomer.ToString)
                Clear()

            End If

        Else

            MessageBox.Show("No customer selected.")

        End If

    End Sub

    Private Sub LoadInfo()

        Dim currentCustomer As PreferredCustomer

        currentCustomer = PreferredCustomers.Item(intCurrentCustomer.ToString)

        ' We convert the current customer's customer number to a string to prevent VB from attempting to
        ' use the number as an index instead of a key
        lblLastName.Text = currentCustomer.LastName
        lblFirstName.Text = currentCustomer.FirstName
        lblAddress.Text = currentCustomer.Address
        lblCity.Text = currentCustomer.City
        lblState.Text = currentCustomer.State
        lblZip.Text = currentCustomer.Zip
        lblPhone.Text = currentCustomer.Phone
        lblCustomer.Text = currentCustomer.CustomerNumber.ToString
        If currentCustomer.MailingList Then
            lblMailingList.Text = "Yes"
        Else
            lblMailingList.Text = "No"
        End If
        lblPurchaseTotal.Text = currentCustomer.PurchasesAmount.ToString("n2")
        lblDiscountLevel.Text = currentCustomer.DiscountLevel.ToString("p")
        lblComments.Text = currentCustomer.Comments

    End Sub

    Private Sub Clear()

        lblLastName.Text = ""
        lblFirstName.Text = ""
        lblAddress.Text = ""
        lblCity.Text = ""
        lblState.Text = ""
        lblZip.Text = ""
        lblPhone.Text = ""
        lblCustomer.Text = ""
        lblMailingList.Text = ""
        lblPurchaseTotal.Text = ""
        lblDiscountLevel.Text = ""
        lblComments.Text = ""

    End Sub

    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click

        Me.Close()

    End Sub

End Class
