﻿Public Class frmSearch

    Private Sub frmSearch_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtCustomer.Clear()

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim intCustomerNumber As Integer

        If Not Integer.TryParse(txtCustomer.Text, intCustomerNumber) Then

            MessageBox.Show("Customer number must be a valid integer value.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        ElseIf Not frmMain.PreferredCustomers.Contains(intCustomerNumber.ToString) Then

            MessageBox.Show("No customer with that customer number exists.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        Else

            frmMain.intCurrentCustomer = intCustomerNumber

            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()

        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

End Class