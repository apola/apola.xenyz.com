﻿Public Class frmAdd

    Private Sub frmAdd_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtLastName.Clear()
        txtFirstName.Clear()
        txtAddress.Clear()
        txtCity.Clear()
        txtState.Clear()
        txtZip.Clear()
        txtPhone.Clear()
        txtCustomer.Clear()
        chkMailingList.Checked = False
        txtPurchaseTotal.Clear()

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim intCustomerNumber As Integer
        Dim decPurchasesAmount As Decimal

        If Not Integer.TryParse(txtCustomer.Text, intCustomerNumber) Then

            MessageBox.Show("Customer number must be a valid integer value.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        ElseIf frmMain.PreferredCustomers.Contains(intCustomerNumber) Then

            MessageBox.Show("Customer with that customer number already exists.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        ElseIf Not Decimal.TryParse(txtPurchaseTotal.Text, decPurchasesAmount) And Not txtPurchaseTotal.Text = "" Then

            MessageBox.Show("Purchase total must be a valid number value.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        ElseIf txtLastName.Text = "" Then

            MessageBox.Show("Please enter customer last name.")
            txtLastName.Focus()

        ElseIf txtFirstName.Text = "" Then

            MessageBox.Show("Please enter customer first name.")
            txtFirstName.Focus()

        ElseIf txtAddress.Text = "" Then

            MessageBox.Show("Please enter customer address.")
            txtAddress.Focus()

        ElseIf txtCity.Text = "" Then

            MessageBox.Show("Please enter customer city.")
            txtCity.Focus()

        ElseIf txtState.Text = "" Then

            MessageBox.Show("Please enter customer state.")
            txtState.Focus()

        ElseIf txtZip.Text = "" Then

            MessageBox.Show("Please enter customer zipcode.")
            txtZip.Focus()

        Else

            Dim newCustomer As New PreferredCustomer

            newCustomer.LastName = txtLastName.Text
            newCustomer.FirstName = txtFirstName.Text
            newCustomer.Address = txtAddress.Text
            newCustomer.City = txtCity.Text
            newCustomer.State = txtState.Text
            newCustomer.Zip = txtZip.Text
            newCustomer.Phone = txtPhone.Text
            newCustomer.CustomerNumber = intCustomerNumber
            newCustomer.MailingList = chkMailingList.Checked
            If Not txtPurchaseTotal.Text = "" Then
                newCustomer.PurchasesAmount = CDec(txtPurchaseTotal.Text)
            End If
            newCustomer.Comments = txtComments.Text

            ' The customer number is an integer, but it's easier to use a string as a collection key because
            ' it uses integers as indexes, not keys
            frmMain.PreferredCustomers.Add(newCustomer, newCustomer.CustomerNumber.ToString)

            MessageBox.Show("Customer saved!")

            frmMain.intCurrentCustomer = newCustomer.CustomerNumber

            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()

        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

End Class