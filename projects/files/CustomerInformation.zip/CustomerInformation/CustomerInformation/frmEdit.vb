﻿Public Class frmEdit

    Dim editCustomer As PreferredCustomer

    Private Sub frmEdit_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        editCustomer = frmMain.PreferredCustomers.Item(frmMain.intCurrentCustomer.ToString)

        txtLastName.Text = editCustomer.LastName
        txtFirstName.Text = editCustomer.FirstName
        txtAddress.Text = editCustomer.Address
        txtCity.Text = editCustomer.City
        txtState.Text = editCustomer.State
        txtZip.Text = editCustomer.Zip
        txtPhone.Text = editCustomer.Phone
        txtCustomer.Text = editCustomer.CustomerNumber.ToString
        If editCustomer.MailingList Then
            chkMailingList.Checked = True
        End If
        txtPurchaseTotal.Text = editCustomer.PurchasesAmount.ToString("n2")

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        Dim intPreviousCustomerNumber As Integer = editCustomer.CustomerNumber
        Dim intNewCustomerNumber As Integer
        Dim decPurchasesAmount As Decimal

        If Not Integer.TryParse(txtCustomer.Text, intNewCustomerNumber) Then

            MessageBox.Show("Customer number must be a valid integer value.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        ElseIf frmMain.PreferredCustomers.Contains(intNewCustomerNumber) And intPreviousCustomerNumber <> intNewCustomerNumber Then

            MessageBox.Show("Customer with that customer number already exists.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        ElseIf Not Decimal.TryParse(txtPurchaseTotal.Text, decPurchasesAmount) And Not txtPurchaseTotal.Text = "" Then

            MessageBox.Show("Purchase total must be a valid number value.")
            txtCustomer.SelectAll()
            txtCustomer.Focus()

        ElseIf txtLastName.Text = "" Then

            MessageBox.Show("Please enter customer last name.")
            txtLastName.Focus()

        ElseIf txtFirstName.Text = "" Then

            MessageBox.Show("Please enter customer first name.")
            txtFirstName.Focus()

        ElseIf txtAddress.Text = "" Then

            MessageBox.Show("Please enter customer address.")
            txtAddress.Focus()

        ElseIf txtCity.Text = "" Then

            MessageBox.Show("Please enter customer city.")
            txtCity.Focus()

        ElseIf txtState.Text = "" Then

            MessageBox.Show("Please enter customer state.")
            txtState.Focus()

        ElseIf txtZip.Text = "" Then

            MessageBox.Show("Please enter customer zipcode.")
            txtZip.Focus()

        Else

            ' The easiest way to update a customer is simply to delete and re-add his information
            frmMain.PreferredCustomers.Remove(editCustomer.CustomerNumber.ToString)

            editCustomer.LastName = txtLastName.Text
            editCustomer.FirstName = txtFirstName.Text
            editCustomer.Address = txtAddress.Text
            editCustomer.City = txtCity.Text
            editCustomer.State = txtState.Text
            editCustomer.Zip = txtZip.Text
            editCustomer.Phone = txtPhone.Text
            editCustomer.CustomerNumber = intNewCustomerNumber
            editCustomer.MailingList = chkMailingList.Checked
            If Not txtPurchaseTotal.Text = "" Then
                editCustomer.PurchasesAmount = CDec(txtPurchaseTotal.Text)
            End If
            editCustomer.Comments = txtComments.Text

            ' The customer number is an integer, but it's easier to use a string as a collection key because
            ' it uses integers as indexes, not keys
            frmMain.PreferredCustomers.Add(editCustomer, editCustomer.CustomerNumber.ToString)

            MessageBox.Show("Customer saved!")

            frmMain.intCurrentCustomer = editCustomer.CustomerNumber

            Me.DialogResult = Windows.Forms.DialogResult.OK
            Me.Close()

        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()

    End Sub

End Class