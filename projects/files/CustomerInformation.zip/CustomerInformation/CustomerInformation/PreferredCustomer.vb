﻿Public Class PreferredCustomer
    Inherits Customer

    Private decPurchasesAmount As Decimal
    Private sngDiscountLevel As Single

    Property PurchasesAmount() As Decimal

        Get

            Return decPurchasesAmount

        End Get

        Set(value As Decimal)

            If value > 2000 Then

                Me.DiscountLevel = 0.1

            ElseIf value > 1500 Then

                Me.DiscountLevel = 0.7

            ElseIf value > 1000 Then

                Me.DiscountLevel = 0.6

            ElseIf value > 500 Then

                Me.DiscountLevel = 0.5

            End If

            decPurchasesAmount = value

        End Set

    End Property

    Property DiscountLevel() As Single

        Get

            Return sngDiscountLevel

        End Get

        Set(value As Single)

            sngDiscountLevel = value

        End Set

    End Property

End Class
